import java.util.Scanner;
class ValidateAgeExecption extends Throwable{
	public ValidateAgeExecption(String errmsg)
	{
		super(errmsg);
	}
}
public class Exercise5 {
	static void validation(int age) throws ValidateAgeExecption{
		if(age>=15)
		{
			throw new ValidateAgeExecption("age of a person is validated");
		}
		else
			System.out.println("age of a person should be above 15");
	}

	public static void main(String[] args) throws ValidateAgeExecption{
		System.out.println("enter age of a person");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		Exercise5.validation(a);
		//System.out.println("rest of the code");
	}
}
