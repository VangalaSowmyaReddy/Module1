
class EmployeeExecption extends Throwable{
	public EmployeeExecption(String Msg){
		
		super(Msg);
	}
}
public class Exercise4 {
	//static String firstName="";
	//static String lastName="";
	
	static String firstName="welcome";
	static String lastName="capgemini";

	static void validation(String firstName, String lastName) throws EmployeeExecption {
				if(firstName.isEmpty()&&lastName.isEmpty())
		{
		throw new EmployeeExecption("firstname and lastname is blank");
		
		}
		else
			System.out.println("firstname and lastname is not blank");
	}

	public static void main(String[] args) throws EmployeeExecption {

		Exercise4.validation(firstName,lastName);
		}
}
