package com.cg.eis.exception;

import java.util.Scanner;

class EmployeeException extends Throwable{
	public EmployeeException(String Msg){
		
		super(Msg);
	}
}
public class Exercise6 {
	static void validation(int salary) throws EmployeeException{
		if(salary<3000)
		throw new EmployeeException("salary is below 3000");
		else
			System.out.println("Employee has valid salary");
	}

	public static void main(String[] args) throws EmployeeException {
		Scanner sc=new Scanner(System.in);
		int salary=sc.nextInt();
		Exercise6.validation(salary);
		//System.out.println("rest of the code");

	}

}
