package labbook10;


	interface Fact{
		int factorial(int a);
	}
	class FactMethod{
		public int Method(int a)
		{
			for(int i=a-1;i>0;i--)
			{
				a=a*i;
			}
			return a;
		}
	}
	public class Exercise5 {
	public static void main(String[] args) {
		FactMethod fm=new FactMethod();
		Fact f=fm::Method;
		System.out.println(f.factorial(6));
	}
	}


