package labbook10;

	interface Authentication
	{
		Boolean Operation(String username,String password);
	}
	public class Exercise3 {
	public static void main(String[] args) {
		Authentication a=(String username,String password) ->{
		if(username==password)
		return true;
		else
			return false;
	};
	System.out.println(a.Operation("abc","abc"));
	}
	}

