package com.cg.eis.bean;

public class EmployeeBean {
private float salary;
private String designation;
private String InsuranceScheme;
public float getSalary() {
	return salary;
}
public void setSalary(float salary) {
	this.salary = salary;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getInsuranceScheme() {
	return InsuranceScheme;
}
public void setInsuranceScheme(String insuranceScheme) {
	InsuranceScheme = insuranceScheme;
}
}
