package lab2_labbook;

import java.util.Scanner;

 class item{
				//abstract void libraryItems();
							void item(int a)
							{
								System.out.println("enter identification number"+a);
							}
							void item(String b)
							{
								System.out.println("enter title"+b);
							}
							void display(double d)
							{
								int c;
								//Scanner s=new Scanner(System.in);
								System.out.println("enter number of copies:"+d);
								// c=s.nextInt();
							}
					}
 class WrittenItem extends item{
							void create(String b1)
							{
								//String s1=null;
								//Scanner s2=new Scanner(System.in);
								System.out.println("enter author name"+b1);
							}
							// TODO Auto-generated constructor stub
							}
 class MediaItem extends item{
	void pop()
	{
		int n=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter an integer:");
		n=sc.nextInt();
		System.out.println("integer is"+n);
	}
	}

 class book extends WrittenItem{
							void item()
							{
								System.out.println("no private data");
							}
							}
 class Journal extends WrittenItem{
							void push(int p)
							{
								System.out.println("year published:"+p);
							}
							}
/*abstract class MediaItem extends item{
							void pop()
							{
								int n=0;
								Scanner sc=new Scanner(System.in);
								System.out.println("enter an integer:");
								n=sc.nextInt();
							}
							}*/
 class Video extends MediaItem{
							void display1(int a)
							{
								System.out.println("enter year released:"+a);
							}
							void display2(String b)
							{
								System.out.println("enter director:"+b);
							}
							void display3(String b1)
							{
								System.out.println("enter genre:"+b1);
							}
							}
 class Cd extends MediaItem{
							void push(String c, String c1)
							{
								System.out.println("enter artist:" + c  +  " enter genre:" + c1);
							}
							}
public class Library_javaprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		book b=new book();
		b.create("kepner");
		b.display(300);
		Journal j=new Journal();
		j.display(25);
		j.create("avery");
		j.push(1998);
		Video v=new Video();
		v.display1(2020);
		v.display2("meredith");
		v.display3("hospital oriented");
		v.pop();
		Cd f=new Cd();
		f.push("derek", "anotomy");
		WrittenItem w=new WrittenItem();
		w.item(86);
		w.item("greys anatomy");
		w.display(14);
		MediaItem k=new MediaItem();
		k.display(12);

	}

}
