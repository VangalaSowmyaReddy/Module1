package labbook8;


	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;

	class copyDataThread extends Thread
	{
		public copyDataThread(FileInputStream f1,FileOutputStream f2)throws IOException,InterruptedException{
		int k=0,c=0;
		while((k=f1.read())!=-1)
	System.out.println((char)k);
		f2.write((char)k);
		c=c+1;
		if(c==10)
		{
			System.out.println("10 characters will be copied");
			Thread.sleep(5);
			c=0;
		}	
	}
	}

	public class FileJava {
	public static void main(String[] args)throws IOException,InterruptedException {
		FileInputStream f1=null;
		f1=new FileInputStream("f://college.txt");
		FileOutputStream f2=null;
		f2=new FileOutputStream("f://college.txt");
		copyDataThread c=new copyDataThread(f1,f2);
	}
	}


