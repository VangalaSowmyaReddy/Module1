package lab3_labbook;


import java.util.Scanner;
public class SortingAlphabeticalOrder
{
    public static void main(String[] args) 
    {
        int n,i;
        String temp;
        Scanner sc = new Scanner(System.in);
        
        //User will be asked to enter the count of strings 
        System.out.print("Enter number of strings you would like to enter:");
        n = sc.nextInt();
        
        
        String s1[] = new String[n];
        Scanner sc1 = new Scanner(System.in);
        
        //User is entering the strings and they are stored in an array
        System.out.println("Enter the Strings one by one:");
        for( i = 0; i < n; i++)
        {
            s1[i] = sc1.nextLine();
        }
        sc.close();
        sc1.close();
        
        //Sorting the strings
        for ( i = 0; i < n; i++) 
        {
            for (int j = i + 1; j < n; j++) { 
                if (s1[i].compareTo(s1[j])>0) 
                {
                    temp = s1[i];
                    s1[i] = s1[j];
                    s1[j] = temp;
                }
            }
        }
        
        //Displaying the strings after sorting them based on alphabetical order
        System.out.print("Strings in Sorted Order:");
        for ( i = 0; i <= n - 1; i++) 
        {
            System.out.print(s1[i] + ", ");
        }
        for(i=0;i<n;i++)
        {
        	if(i<(n+1)/2){
        System.out.println(s1[i].toUpperCase());
        	}
        	else
        	{
        		System.out.println(s1[i].toLowerCase());
        	}
        }
    }
}