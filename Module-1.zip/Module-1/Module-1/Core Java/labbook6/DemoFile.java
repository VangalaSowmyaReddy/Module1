package lab6_labbook;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class DemoFile {

	public static void main(String[] args) throws IOException {
		System.out.println("enter file name with .txt which has text written");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		FileReader fr = new FileReader(s);
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		int i=1;
		while (line != null) {
			System.out.println("line "+ i +":"+line);
			i++;
			line = br.readLine();
			
		}
		br.close();
		

	}

}
