package labbook9;

public class Exercise {

}
